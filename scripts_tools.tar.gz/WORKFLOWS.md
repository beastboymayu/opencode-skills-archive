# OpenCode Workflows

Predefined workflows for common tasks. These guide the AI through complex multi-step processes using available skills.

---

## Workflow 1: New Feature Development

**When:** Building a new feature

**Steps:**
1. **Analyze** - Understand requirements, check existing code structure
2. **Plan** - Use @architect or planning-with-files to design the feature
3. **Implement** - Build the feature with proper patterns
4. **Test** - Write tests using @tester guidance or test-driven-development
5. **Review** - Run @code-reviewer for quality check
6. **Verify** - Ensure tests pass using verification-before-completion

**Key Skills:**
- `planning-with-files` - Manus-style planning
- `architecture-designer` - System design
- `test-driven-development` - TDD workflow
- `code-reviewer` - Quality review
- `api-endpoint-builder` - API creation
- `verification-before-completion` - Final check

---

## Workflow 2: Bug Fix

**When:** Fixing a reported bug

**Steps:**
1. **Reproduce** - Get exact steps to reproduce
2. **Investigate** - Use systematic-debugging to trace the issue
3. **Fix** - Implement the fix
4. **Test** - Verify the bug is fixed
5. **Review** - Check for edge cases

**Key Skills:**
- `systematic-debugging` - Structured debugging
- `bug-hunter` - Bug investigation
- `testing-patterns` - Test patterns
- `error-detective` - Log analysis

---

## Workflow 3: Code Review

**When:** Reviewing code changes

**Steps:**
1. **Security** - Run security-auditor for vulnerabilities
2. **Quality** - Run code-reviewer for code quality
3. **Performance** - Check with performance-expert
4. **Testing** - Verify test coverage
5. **Suggest** - Provide actionable feedback

**Key Skills:**
- `security-auditor` - Security review
- `code-reviewer` - Code quality
- `performance-profiler` - Performance analysis
- `uncle-bob-craft` - Clean code principles

---

## Workflow 4: UI/UX Development

**When:** Building user interfaces

**Steps:**
1. **Design** - Use ui-ux-pro-max or design-taste-frontend for design system
2. **Component** - Build with shadcn-ui or tailwind-design-system
3. **Style** - Apply minimalist-ui or industrial-brutalist-ui
4. **Animate** - Use framer-motion for animations
5. **Accessibility** - Verify with wcag-audit-patterns
6. **Visual Test** - Use webfetch to verify rendered output

**Key Skills:**
- `ui-ux-pro-max` - Design system generator
- `design-taste-frontend` - Premium frontend design
- `tailwind-design-system` - Tailwind CSS patterns
- `shadcn-ui` - Component patterns
- `minimalist-ui` - Clean interfaces
- `high-end-visual-design` - Premium animations

**Verification:**
- Start dev server and use webfetch to test pages
- Verify responsive design, animations, interactions
- Check accessibility with wcag-audit-patterns

---

## Workflow 5: DevOps & Infrastructure

**When:** Setting up infrastructure or CI/CD

**Steps:**
1. **Plan** - Use terraform-generator or ansible-generator
2. **Container** - Create dockerfile-generator
3. **Orchestrate** - Use k8s-yaml-generator for Kubernetes
4. **CI/CD** - Generate github-actions-generator or gitlab-ci-generator
5. **Validate** - Use terraform-validator or dockerfile-validator

**Key Skills:**
- `terraform-generator` - Terraform IaC
- `terraform-validator` - TF validation
- `ansible-generator` - Ansible playbooks
- `dockerfile-generator` - Dockerfiles
- `k8s-debug` - Kubernetes debugging
- `github-actions-generator` - GitHub Actions

---

## Workflow 6: Security Audit

**When:** Performing security reviews

**Steps:**
1. **Scan** - Use vulnerability-detection for common issues
2. **Test** - Use ffuf-web-fuzzing for web penetration
3. **Review** - Run security-auditor for comprehensive check
4. **Remediate** - Document findings and fixes

**Key Skills:**
- `security-auditor` - Comprehensive security
- `vulnerability-detection` - Issue detection
- `ffuf-web-fuzzing` - Web penetration testing
- `penetration-testing` - Security testing

---

## Workflow 7: SEO & Content

**When:** Creating content or optimizing for search

**Steps:**
1. **Research** - Use seo-keyword-strategist for keyword research
2. **Plan** - Use seo-content-planner for content strategy
3. **Write** - Use seo-content-writer for optimized content
4. **Audit** - Verify with seo-audit

**Key Skills:**
- `seo-audit` - SEO analysis
- `seo-keyword-strategist` - Keyword research
- `seo-content-writer` - Content writing
- `seo-content-planner` - Content strategy
- `content-creator` - Brand content

---

## Workflow 8: Database Development

**When:** Working with databases

**Steps:**
1. **Design** - Use database-schema-designer for schema
2. **Query** - Use sql-database-assistant for queries
3. **Optimize** - Use database-optimizer for performance
4. **Migrate** - Plan with migration-architect

**Key Skills:**
- `database-schema-designer` - Schema design
- `sql-database-assistant` - SQL queries
- `database-optimizer` - Performance tuning
- `postgresql-expert` - PostgreSQL

---

## Workflow 9: AI/ML Development

**When:** Building AI or ML features

**Steps:**
1. **Architect** - Use rag-architect for retrieval systems
2. **Optimize** - Use llm-cost-optimizer for LLM optimization
3. **Evaluate** - Use agent-evaluation for AI evaluation

**Key Skills:**
- `rag-architect` - RAG systems
- `llm-cost-optimizer` - LLM optimization
- `ml-engineering` - ML development
- `data-science` - Data analysis
- `agent-evaluation` - AI evaluation

---

## Workflow 10: Full Stack Development

**When:** Building complete applications

**Steps:**
1. **Plan** - Use planning-with-files for project planning
2. **Backend** - Use python-expert, nodejs-expert, or golang-expert
3. **Frontend** - Use react-expert or vue-expert
4. **Database** - Use database-schema-designer
5. **Deploy** - Use terraform-generator + dockerfile-generator
6. **Test** - Use e2e-testing-patterns for end-to-end testing
7. **Visual Verify** - Start dev server, use webfetch to verify

**Key Skills:**
- `planning-with-files` - Project planning
- `python-expert` - Python backend
- `nodejs-expert` - Node.js backend
- `react-expert` - React frontend
- `vue-expert` - Vue frontend
- `e2e-testing-patterns` - End-to-end testing
- `fullstack-guardian` - Full stack oversight

**Visual Verification:**
- Run dev server (npm run dev / python manage.py runserver)
- Use webfetch to fetch and verify rendered HTML
- Test interactive elements, forms, navigation
- Verify responsive design and animations
- Check console for errors via fetched content

---

## Workflow 11: Project Management

**When:** Managing project tasks

**Steps:**
1. **Discovery** - Use product-discovery for requirements
2. **Plan** - Use product-manager-toolkit for planning
3. **Track** - Use agile-product-owner for sprint management

**Key Skills:**
- `product-discovery` - Requirements gathering
- `product-manager-toolkit` - PM tools
- `agile-product-owner` - Agile management

---

## Workflow 12: Marketing & Growth

**When:** Marketing activities

**Steps:**
1. **Strategy** - Use marketing-ideas for campaign ideas
2. **Content** - Use copywriting for ads
3. **Social** - Use social-content for social media

**Key Skills:**
- `marketing-ideas` - Campaign ideas
- `copywriting` - Ad copy
- `social-content` - Social media
- `paid-ads` - Paid advertising

---

(End of file)
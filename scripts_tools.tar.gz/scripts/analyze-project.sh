#!/bin/bash
# Project Structure Analyzer
# Analyzes and reports on project structure

PROJECT_DIR="${1:-.}"

echo "=== Project Structure Analysis ==="
echo ""

echo "--- Files by Type ---"
find "$PROJECT_DIR" -type f \( -name "*.js" -o -name "*.ts" -o -name "*.jsx" -o -name "*.tsx" -o -name "*.py" -o -name "*.go" -o -name "*.java" \) 2>/dev/null | wc -l | xargs -I {} echo "Source files: {}"

echo ""
echo "--- Directory Structure (top 3 levels) ---"
find "$PROJECT_DIR" -maxdepth 3 -type d 2>/dev/null | grep -v node_modules | grep -v ".git" | head -20

echo ""
echo "--- Package.json ---"
if [ -f "$PROJECT_DIR/package.json" ]; then
    echo "Dependencies: $(node -p 'require("./package.json").dependencies ? Object.keys(require("./package.json").dependencies).length : 0' 2>/dev/null || echo "N/A")"
    echo "DevDependencies: $(node -p 'require("./package.json").devDependencies ? Object.keys(require("./package.json").devDependencies).length : 0' 2>/dev/null || echo "N/A")"
fi

echo ""
echo "--- Git Info ---"
cd "$PROJECT_DIR"
if [ -d ".git" ]; then
    echo "Branch: $(git branch --show-current 2>/dev/null || echo "N/A")"
    echo "Last commit: $(git log -1 --oneline 2>/dev/null || echo "N/A")"
fi
#!/bin/bash
# Quick Code Quality Check
# Runs basic quality checks on the project

PROJECT_DIR="${1:-.}"

echo "=== Code Quality Check ==="
echo ""

cd "$PROJECT_DIR"

echo "--- Finding TODO/FIXME comments ---"
grep -r "TODO\|FIXME\|HACK\|XXX" --include="*.js" --include="*.ts" --include="*.jsx" --include="*.tsx" --include="*.py" --include="*.go" . 2>/dev/null | head -20 || echo "None found"

echo ""
echo "--- Checking for console.log ---"
grep -r "console.log" --include="*.js" --include="*.ts" --include="*.jsx" --include="*.tsx" . 2>/dev/null | wc -l | xargs -I {} echo "console.log statements: {}"

echo ""
echo "--- Checking for hardcoded secrets ---"
grep -rE "password\s*=\s*[\"']|api[_-]?key\s*=\s*[\"']|secret\s*=\s*[\"']" --include="*.js" --include="*.ts" --include="*.json" . 2>/dev/null | head -10 || echo "None found"

echo ""
echo "--- Empty catch blocks ---"
grep -r "catch.*{\s*}" --include="*.js" --include="*.ts" --include="*.jsx" --include="*.tsx" . 2>/dev/null | head -10 || echo "None found"

echo ""
echo "--- Large files (>500 lines) ---"
find . -type f \( -name "*.js" -o -name "*.ts" -o -name "*.jsx" -o -name "*.tsx" -o -name "*.py" -o -name "*.go" \) -exec wc -l {} \; 2>/dev/null | grep -v node_modules | sort -rn | head -10
#!/bin/bash
# Skill Installer Agent - For use by other agents
# Provides programmatic interface for skill installation
#
# This script is designed to be sourced or called from other agents
# when they need to install a skill autonomously

set -euo pipefail

SKILLS_DIR="/.agents/skills"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Agent-facing function: Check if skill is available
skill_available() {
    local skill_name="$1"
    
    # Check local
    if [ -d "$SKILLS_DIR/$skill_name" ] && [ -f "$SKILLS_DIR/$skill_name/SKILL.md" ]; then
        echo "local"
        return 0
    fi
    
    # Check if we can install it
    # For now, return "available" if it might exist remotely
    echo "available"
    return 0
}

# Agent-facing function: Install skill
install_skill_for_agent() {
    local skill_name="$1"
    local source_repo="${2:-}"
    
    if [ -d "$SKILLS_DIR/$skill_name" ] && [ -f "$SKILLS_DIR/$skill_name/SKILL.md" ]; then
        echo "already_installed:$skill_name"
        return 0
    fi
    
    # Use install script
    if [ -n "$source_repo" ]; then
        "$SCRIPT_DIR/install-skill.sh" "$source_repo/$skill_name" 2>&1 && \
            echo "installed:$skill_name" || echo "failed:$skill_name"
    else
        "$SCRIPT_DIR/auto-install-skill.sh" "$skill_name" 2>&1 && \
            echo "installed:$skill_name" || echo "failed:$skill_name"
    fi
}

# Agent-facing function: Get skill path
get_skill_path() {
    local skill_name="$1"
    
    if [ -d "$SKILLS_DIR/$skill_name" ]; then
        echo "$SKILLS_DIR/$skill_name"
        return 0
    fi
    return 1
}

# Export functions if being sourced
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    export -f skill_available
    export -f install_skill_for_agent
    export -f get_skill_path
    export SKILLS_DIR
fi

# Handle direct invocation
if [ $# -gt 0 ]; then
    case "$1" in
        --available|-a)
            skill_available "${2:-}"
            ;;
        --install|-i)
            install_skill_for_agent "${2:-}" "${3:-}"
            ;;
        --path|-p)
            get_skill_path "${2:-}"
            ;;
        *)
            echo "Usage: $0 [--available|--install|--path] <skill-name> [source]"
            ;;
    esac
fi
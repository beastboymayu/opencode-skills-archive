#!/bin/bash
# Dependency Audit Script
# Checks for outdated packages and vulnerabilities

PROJECT_DIR="${1:-.}"

echo "=== Dependency Audit ==="
echo ""

cd "$PROJECT_DIR"

if [ -f "package.json" ]; then
    echo "--- npm audit ---"
    npm audit --json 2>/dev/null | node -e "
const data = require('/dev/stdin');
const vulns = data.vulnerabilities || {};
console.log('Total vulnerabilities:', Object.values(vulns).reduce((a, b) => a + (b.length || 0), 0));
" 2>/dev/null || echo "Run npm audit manually for detailed results"
    
    echo ""
    echo "--- Checking for outdated packages ---"
    npm outdated --json 2>/dev/null | node -e "
const data = require('/dev/stdin');
const pkgs = Object.keys(data);
if (pkgs.length === 0) console.log('All packages are up to date');
else {
    console.log('Outdated packages:');
    pkgs.forEach(p => console.log('  -', p, '(current:', data[p].current, ', wanted:', data[p].wanted, ')'));
}
" 2>/dev/null || echo "No package.json or npm not installed"
fi

if [ -f "requirements.txt" ]; then
    echo ""
    echo "--- Python dependencies ---"
    pip list --outdated 2>/dev/null | head -20 || echo "pip not available"
fi

if [ -f "go.mod" ]; then
    echo ""
    echo "--- Go dependencies ---"
    go list -u -m all 2>/dev/null | grep -v "go:" | head -20 || echo "go not available"
fi
#!/bin/bash
# Enhanced Skills.sh Installer for OpenCode
# Production-ready skill installation with validation and auto-discovery
#
# Usage: 
#   ./install-skill.sh <owner/repo/skill-name> [category]
#   ./install-skill.sh --verify [skill-name]
#   ./install-skill.sh --list-installed
#   ./install-skill.sh --search <query>
#
# Options:
#   --verify          Verify installed skills have valid SKILL.md
#   --list-installed  List all manually installed skills
#   --search        Search skills.sh for skills
#   --category      Optional category (frontend/backend/ai/security/etc)

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="/.agents/skills"
MANIFEST_FILE="$SCRIPT_DIR/.installed-skills.json"
LOG_FILE="$SCRIPT_DIR/install-skill.log"

# Logging function
log() {
    local level="$1"
    shift
    local msg="[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $*"
    echo -e "$msg" | tee -a "$LOG_FILE" 2>/dev/null || echo "$msg"
}

# Error handling
error_exit() {
    log "ERROR" "$1" >&2
    exit "${2:-1}"
}

# Parse arguments
VERBOSE=""
FORCE=""
CATEGORY=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --verify)
            ACTION="verify"
            shift
            ;;
        --list-installed|--list)
            ACTION="list"
            shift
            ;;
        --search|-s)
            ACTION="search"
            shift
            ;;
        --verbose|-v)
            VERBOSE="1"
            shift
            ;;
        --force|-f)
            FORCE="1"
            shift
            ;;
        --category|-c)
            CATEGORY="$2"
            shift 2
            ;;
        -*)
            error_exit "Unknown option: $1"
            ;;
        *)
            break
            ;;
    esac
done

# Remaining arguments become the input
INPUT="${1:-}"
TARGET_CATEGORY="${2:-}"

# Initialize manifest if it doesn't exist
init_manifest() {
    if [ ! -f "$MANIFEST_FILE" ]; then
        echo '{"skills":[]}' > "$MANIFEST_FILE"
    fi
}

# Add skill to manifest
add_to_manifest() {
    local skill_name="$1"
    local source_repo="$2"
    local category="$3"
    local installed_at="$(date -Iseconds)"
    
    init_manifest
    
    # Use jq if available, otherwise use simple sed
    if command -v jq &>/dev/null; then
        local temp_file=$(mktemp)
        jq --arg name "$skill_name" \
           --arg repo "$source_repo" \
           --arg category "$category" \
           --arg installed "$installed_at" \
           '.skills += [{"name":$name,"source":$repo,"category":$category,"installed":$installed_at}]' \
           "$MANIFEST_FILE" > "$temp_file"
        mv "$temp_file" "$MANIFEST_FILE"
    else
        # Fallback: append manually
        local uuid=$(uuidgen 2>/dev/null || echo "manual-$$")
        echo ",{\"name\":\"$skill_name\",\"source\":\"$source_repo\",\"category\":\"$category\",\"installed\":\"$installed_at\"}" >> "$MANIFEST_FILE"
        # Fix JSON structure at end
        sed -i 's/\]}/]}/;s/}\]}/]}/' "$MANIFEST_FILE" 2>/dev/null || true
    fi
}

# Check if skill exists in manifest
skill_exists() {
    local skill_name="$1"
    init_manifest
    grep -q "\"$skill_name\"" "$MANIFEST_FILE" 2>/dev/null || [ ! -d "$SKILLS_DIR/$skill_name" ]
}

# Verify skill integrity
verify_skill() {
    local skill_name="$1"
    local skill_path="$SKILLS_DIR/$skill_name"
    
    [ -d "$skill_path" ] || {
        echo -e "${RED}✗${NC} Skill directory not found: $skill_path"
        return 1
    }
    
    [ -f "$skill_path/SKILL.md" ] || {
        echo -e "${RED}✗${NC} Missing SKILL.md file"
        return 1
    }
    
    # Check for common required files
    local has_content=0
    for file in "$skill_path"/*; do
        if [ -f "$file" ] && [ "$(wc -c < "$file")" -gt 0 ]; then
            has_content=1
            break
        fi
    done
    
    [ "$has_content" -eq 1 ] || {
        echo -e "${RED}✗${NC} Skill has no content"
        return 1
    }
    
    return 0
}

# List installed skills
list_installed() {
    echo -e "${BLUE}Installed Skills${NC}"
    echo "====================="
    
    if [ -d "$SKILLS_DIR" ]; then
        local count=0
        for dir in "$SKILLS_DIR"/*/; do
            local skill_name="$(basename "$dir")"
            if [ -f "$dir/SKILL.md" ]; then
                count=$((count + 1))
                echo -e "  ${GREEN}✓${NC} $skill_name"
            fi
        done
        echo ""
        echo "Total: $count skills with SKILL.md"
    else
        echo "No skills directory found"
    fi
}

# Search skills.sh via GitHub API
search_skills() {
    local query="$1"
    
    [ -n "$query" ] || error_exit "Search query required"
    
    echo -e "${BLUE}Searching skills.sh for: $query${NC}"
    echo "========================================"
    
    # Try multiple search approaches
    local results=""
    results=$(curl -s --max-time 10 \
        "https://api.github.com/search/repositories?q=skills+${query}+in:name,description&per_page=20" \
        2>/dev/null | jq -r '.items[]? | "\(.full_name)|\(.description // "No description")"' 2>/dev/null) || true
    
    if [ -n "$results" ]; then
        echo "$results" | while IFS='|' read -r name desc; do
            [ -n "$name" ] && echo -e "${GREEN}$name${NC}\n  $desc\n"
        done
    else
        echo "No results found. Try different keywords."
        echo ""
        echo "Search tips:"
        echo "  - react, vue, svelte (frontend)"
        echo "  - seo, marketing, copywriting"
        echo "  - aws, terraform, kubernetes"
        echo "  - security, testing"
    fi
}

# Determine category from skill name
guess_category() {
    local skill_name="$1"
    local name_lower="$(echo "$skill_name" | tr '[:upper:]' '[:lower:]')"
    
    # Category heuristics
    case "$name_lower" in
        *react*|*vue*|*svelte*|*nextjs*|*html*|*css*|*ui*|*frontend*)
            echo "frontend"
            ;;
        *python*|*nodejs*|*golang*|*rust*|*java*|*api*|*backend*|*server*)
            echo "backend"
            ;;
        *ai*|*ml*|*llm*|*rag*|*openai*|*anthropic*)
            echo "ai"
            ;;
        *security*|*audit*|*pen-testing*|*vulnerability*)
            echo "security"
            ;;
        *database*|*sql*|*postgres*|*mysql*)
            echo "database"
            ;;
        *aws*|*azure*|*gcp*|*terraform*|*k8s*|*docker*)
            echo "devops"
            ;;
        *test*|*playwright*|*cypress*|*qa*)
            echo "testing"
            ;;
        *seo*|*marketing*|*copy*|*content*)
            echo "marketing"
            ;;
        *)
            echo "utils"
            ;;
    esac
}

# Main installation function
install_skill() {
    [ -n "$INPUT" ] || {
        echo "Usage: $0 <owner/repo/skill-name> [category]"
        echo "       $0 --verify [skill-name]"
        echo "       $0 --list-installed"
        echo "       $0 --search <query>"
        exit 1
    }
    
    # Parse owner/repo/skill
    local OWNER REPO SKILL_NAME
    IFS='/' read -r OWNER REPO SKILL_NAME <<< "$INPUT"
    
    [ -n "$SKILL_NAME" ] || error_exit "Invalid format. Use owner/repo/skill-name"
    
    local full_repo="$OWNER/$REPO"
    local dest_dir="$SKILLS_DIR/$SKILL_NAME"
    
    # Determine category
    local category="${TARGET_CATEGORY:-$(guess_category "$SKILL_NAME")}"
    
    # Check if already installed
    if [ -d "$dest_dir" ] && [ -z "$FORCE" ]; then
        if verify_skill "$SKILL_NAME" 2>/dev/null; then
            echo -e "${YELLOW}Skill already exists and verified: $SKILL_NAME${NC}"
            echo "Use --force to reinstall"
            return 0
        fi
    fi
    
    echo -e "${BLUE}Installing $full_repo/$SKILL_NAME...${NC}"
    
    # Clone repository
    local temp_dir
    temp_dir=$(mktemp -d) || error_exit "Failed to create temp directory"
    
    # Ensure cleanup on error
    trap "rm -rf '$temp_dir' 2>/dev/null || true" EXIT
    
    log "INFO" "Cloning $full_repo"
    
    if ! git clone --depth 1 --single-branch "https://github.com/$full_repo.git" "$temp_dir" 2>&1 | tee -a "$LOG_FILE"; then
        error_exit "Could not clone repository: $full_repo"
    fi
    
    # Find the skill directory
    local source_dir=""
    
    # Strategy 1: Check skills/ subdirectory (common for skill packs)
    if [ -d "$temp_dir/skills/$SKILL_NAME" ]; then
        source_dir="$temp_dir/skills/$SKILL_NAME"
    # Strategy 2: Check root level exact match
    elif [ -d "$temp_dir/$SKILL_NAME" ]; then
        source_dir="$temp_dir/$SKILL_NAME"
    # Strategy 3: Find directory with matching SKILL.md
    else
        for dir in "$temp_dir"/*/; do
            local dirname
            dirname=$(basename "$dir")
            if [ "$dirname" = "$SKILL_NAME" ] && [ -f "$dir/SKILL.md" ]; then
                source_dir="$dir"
                break
            fi
        done
    fi
    
    # Strategy 4: Case-insensitive search
    if [ -z "$source_dir" ]; then
        for dir in "$temp_dir"/*/; do
            local dirname
            dirname=$(basename "$dir")
            if [ "$(echo "$dirname" | tr '[:upper:]' '[:lower:]')" = "$(echo "$SKILL_NAME" | tr '[:upper:]' '[:lower:]')" ] && [ -f "$dir/SKILL.md" ]; then
                source_dir="$dir"
                break
            fi
        done
    fi
    
    [ -n "$source_dir" ] || {
        log "ERROR" "Skill '$SKILL_NAME' not found in repository"
        echo "Available directories:"
        ls -la "$temp_dir" 2>/dev/null || true
        ls -la "$temp_dir/skills" 2>/dev/null || true
        exit 1
    }
    
    # Verify skill has SKILL.md
    if [ ! -f "$source_dir/SKILL.md" ]; then
        error_exit "Source does not contain SKILL.md file"
    fi
    
    # Create destination directory
    mkdir -p "$dest_dir"
    
    # Copy skill files
    log "INFO" "Copying files to $dest_dir"
    cp -r "$source_dir"/* "$dest_dir/" 2>&1 | tee -a "$LOG_FILE" || {
        error_exit "Failed to copy skill files"
    }
    
    # Verify installation
    if verify_skill "$SKILL_NAME"; then
        log "INFO" "Skill verified: $SKILL_NAME"
        add_to_manifest "$SKILL_NAME" "$full_repo" "$category"
        echo -e "${GREEN}✓${NC} Successfully installed $SKILL_NAME to $dest_dir"
        echo -e "${GREEN}✓${NC} Skill '$SKILL_NAME' is now available"
    else
        error_exit "Skill verification failed"
    fi
    
    # Cleanup
    rm -rf "$temp_dir"
    trap - EXIT
}

# Verify all or specific skill
verify_all() {
    local target_skill="${1:-}"
    
    if [ -n "$target_skill" ]; then
        # Verify specific skill
        echo -e "${BLUE}Verifying: $target_skill${NC}"
        if verify_skill "$target_skill"; then
            echo -e "${GREEN}✓${NC} $target_skill is valid"
            return 0
        else
            echo -e "${RED}✗${NC} $target_skill has issues"
            return 1
        fi
    fi
    
    # Verify all skills
    echo -e "${BLUE}Verifying all skills in $SKILLS_DIR${NC}"
    echo "======================================"
    
    local valid=0
    local invalid=0
    
    for dir in "$SKILLS_DIR"/*/; do
        local skill_name
        skill_name=$(basename "$dir")
        
        if verify_skill "$skill_name" 2>/dev/null; then
            echo -e "${GREEN}✓${NC} $skill_name"
            valid=$((valid + 1))
        else
            echo -e "${RED}✗${NC} $skill_name"
            invalid=$((invalid + 1))
        fi
    done
    
    echo ""
    echo "Summary: $valid valid, $invalid with issues"
    
    [ "$invalid" -eq 0 ]
}

# Main entry point
main() {
    # Create log file
    touch "$LOG_FILE" 2>/dev/null || true
    
    case "${ACTION:-install}" in
        install)
            install_skill
            ;;
        verify)
            verify_all "$INPUT"
            ;;
        list)
            list_installed
            ;;
        search)
            search_skills "$INPUT"
            ;;
        *)
            echo "Unknown action: $ACTION"
            exit 1
            ;;
    esac
}

main
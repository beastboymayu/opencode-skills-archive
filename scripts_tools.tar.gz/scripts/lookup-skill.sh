#!/bin/bash
# Enhanced Skill Lookup - Search and discover skills for OpenCode
# 
# Usage:
#   ./lookup-skill.sh                    # Interactive mode
#   ./lookup-skill.sh <query>          # Search by keyword
#   ./lookup-skill.sh --category <cat>  # List by category
#   ./lookup-skill.sh --installed       # Show installed skills
#   ./lookup-skill.sh --verify         # Verify all skills

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

SKILLS_DIR="/.agents/skills"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Categories for filtering
CATEGORIES=(
    "frontend:React,Vue,Svelte,UI,Design"
    "backend:API,Server,Database"
    "ai:AI,ML,LLM,RAG,Prompt"
    "devops:Docker,Kubernetes,Terraform,AWS"
    "security:Security,Audit,Penetration"
    "testing:Test,Playwright,QA,E2E"
    "marketing:SEO,Content,Copy,Marketing"
    "product:Product,PM,Strategy"
    "database:SQL,PostgreSQL,NoSQL"
    "workflows:Planning,Debugging,TDD"
)

# Print colored output
print_skill() {
    local name="$1"
    local desc="$2"
    local status="$3"  # installed, available, or remote
    
    case "$status" in
        installed)
            echo -e "  ${GREEN}✓${NC} $name"
            ;;
        available)
            echo -e "  ${CYAN}○${NC} $name"
            ;;
        remote)
            echo -e "  ${MAGENTA}?${NC} $name"
            ;;
    esac
    
    if [ -n "$desc" ]; then
        echo "      $desc"
    fi
}

# Search locally installed skills
search_local() {
    local query="$1"
    local count=0
    
    if [ ! -d "$SKILLS_DIR" ]; then
        echo "No skills directory found"
        return
    fi
    
    for dir in "$SKILLS_DIR"/*/; do
        local skill_name
        skill_name=$(basename "$dir")
        
        # Match against name
        if [[ "$skill_name" == *"$query"* ]]; then
            print_skill "$skill_name" "" "installed"
            count=$((count + 1))
            continue
        fi
        
        # Match against SKILL.md content
        if [ -f "$dir/SKILL.md" ]; then
            if grep -qi "$query" "$dir/SKILL.md" 2>/dev/null; then
                local desc
                desc=$(head -3 "$dir/SKILL.md" | tail -1 | sed 's/^#* *//' | cut -c1-80)
                print_skill "$skill_name" "$desc" "installed"
                count=$((count + 1))
            fi
        fi
    done
    
    if [ "$count" -eq 0 ]; then
        echo "No local skills matching '$query'"
    fi
}

# Search remote via GitHub API
search_remote() {
    local query="$1"
    
    echo -e "${BLUE}Searching skills.sh for: $query${NC}"
    echo "=================================="
    echo ""
    
    local results
    results=$(curl -s --max-time 10 \
        "https://api.github.com/search/repositories?q=$query+skills+OR+skill+in:name,description&per_page=15" \
        2>/dev/null | jq -r '.items[]? | "\(.full_name)|\(.description // "")"' 2>/dev/null) || true
    
    if [ -n "$results" ]; then
        echo "$results" | while IFS='|' read -r name desc; do
            [ -n "$name" ] || continue
            # Extract skill name from repo
            local skill_name="${name##*/}"
            print_skill "$skill_name" "$desc" "remote"
        done
    else
        echo "No remote results. Try broader terms."
    fi
}

# List by category
list_by_category() {
    local category="$1"
    local count=0
    
    echo -e "${BLUE}Skills in category: $category${NC}"
    echo "================================="
    
    for dir in "$SKILLS_DIR"/*/; do
        local skill_name
        skill_name=$(basename "$dir")
        
        # Check if skill matches category keywords
        local match=0
        case "$category" in
            frontend)
                [[ "$skill_name" =~ react|vue|svelte|nextjs|html|css|ui|frontend ]] && match=1
                ;;
            backend)
                [[ "$skill_name" =~ api|backend|server|express|fastapi|django ]] && match=1
                ;;
            ai)
                [[ "$skill_name" =~ ai|ml|llm|rag|prompt|gpt|openai ]] && match=1
                ;;
            devops)
                [[ "$skill_name" =~ docker|kubernetes|k8s|terraform|aws|azure|gcp|devops ]] && match=1
                ;;
            security)
                [[ "$skill_name" =~ security|audit|penetration|vuln|secure ]] && match=1
                ;;
            testing)
                [[ "$skill_name" =~ test|playwright|cypress|qa|e2e ]] && match=1
                ;;
            marketing)
                [[ "$skill_name" =~ seo|marketing|content|copy|social ]] && match=1
                ;;
            product)
                [[ "$skill_name" =~ product|pm|strategy|roadmap ]] && match=1
                ;;
            database)
                [[ "$skill_name" =~ sql|database|postgres|mysql|mongo ]] && match=1
                ;;
            *)
                match=1
                ;;
        esac
        
        if [ "$match" -eq 1 ]; then
            print_skill "$skill_name" "" "installed"
            count=$((count + 1))
        fi
    done
    
    echo ""
    echo "Total: $count skills in '$category'"
}

# Show installed skills with details
show_installed() {
    echo -e "${BLUE}Installed Skills in OpenCode${NC}"
    echo "============================="
    echo ""
    
    local count=0
    local total_size=0
    
    for dir in "$SKILLS_DIR"/*/; do
        local skill_name
        skill_name=$(basename "$dir")
        
        # Get skill size
        local size
        size=$(du -sh "$dir" 2>/dev/null | cut -f1)
        
        # Get description from SKILL.md
        local desc=""
        if [ -f "$dir/SKILL.md" ]; then
            desc=$(head -3 "$dir/SKILL.md" | tail -1 | sed 's/^#* *//' | cut -c1-60)
        fi
        
        echo -e "${GREEN}•${NC} $skill_name ($size)"
        [ -n "$desc" ] && echo "    $desc"
        echo ""
        
        count=$((count + 1))
    done
    
    echo "================================="
    echo "Total installed: $count skills"
}

# Verify all skills
verify_all() {
    echo -e "${BLUE}Verifying Skills${NC}"
    echo "=================="
    echo ""
    
    local valid=0
    local invalid=0
    
    for dir in "$SKILLS_DIR"/*/; do
        local skill_name
        skill_name=$(basename "$dir")
        
        # Check for SKILL.md
        if [ -f "$dir/SKILL.md" ]; then
            # Check for content
            if [ -s "$dir/SKILL.md" ]; then
                echo -e "${GREEN}✓${NC} $skill_name"
                valid=$((valid + 1))
            else
                echo -e "${RED}✗${NC} $skill_name (empty)"
                invalid=$((invalid + 1))
            fi
        else
            echo -e "${RED}✗${NC} $skill_name (no SKILL.md)"
            invalid=$((invalid + 1))
        fi
    done
    
    echo ""
    echo "Summary: $valid valid, $invalid with issues"
}

# Show help
show_help() {
    cat <<EOF
Enhanced Skill Lookup for OpenCode

Usage:
  $(basename "$0") <query>              Search local skills
  $(basename "$0") --remote <query>     Search skills.sh
  $(basename "$0") --category <cat>      List by category
  $(basename "$0") --installed          Show all installed
  $(basename "$0") --verify            Verify all skills
  
Categories: frontend, backend, ai, devops, security, testing, marketing, product, database

Examples:
  $(basename "$0") react
  $(basename "$0") --remote "playwright"
  $(basename "$0") --category ai
  $(basename "$0") --installed
EOF
}

# Parse arguments
MODE="search"
QUERY=""
CATEGORY=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --remote|-r)
            MODE="remote"
            shift
            ;;
        --category|-c)
            MODE="category"
            CATEGORY="$2"
            shift 2
            ;;
        --installed|-i)
            MODE="installed"
            shift
            ;;
        --verify|-v)
            MODE="verify"
            shift
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        -*)
            echo "Unknown option: $1"
            show_help
            exit 1
            ;;
        *)
            QUERY="$1"
            shift
            ;;
    esac
done

# Execute based on mode
case "$MODE" in
    search)
        if [ -n "$QUERY" ]; then
            search_local "$QUERY"
        else
            show_help
        fi
        ;;
    remote)
        if [ -n "$QUERY" ]; then
            search_remote "$QUERY"
        else
            echo "Specify search query"
            exit 1
        fi
        ;;
    category)
        if [ -n "$CATEGORY" ]; then
            list_by_category "$CATEGORY"
        else
            echo "Available categories:"
            echo "  frontend, backend, ai, devops, security, testing, marketing, product, database"
            exit 1
        fi
        ;;
    installed)
        show_installed
        ;;
    verify)
        verify_all
        ;;
esac
#!/bin/bash
# Quick Test Runner
# Runs available tests in the project

PROJECT_DIR="${1:-.}"

echo "=== Running Tests ==="
echo ""

cd "$PROJECT_DIR"

if [ -f "package.json" ]; then
    if grep -q '"test"' package.json; then
        echo "Running npm tests..."
        npm test 2>&1 | tail -50
    else
        echo "No test script found in package.json"
    fi
elif [ -f "pytest.ini" ] || [ -f "setup.py" ] || [ -f "pyproject.toml" ]; then
    echo "Running Python tests..."
    pytest --tb=short 2>&1 | tail -50 || echo "pytest not found"
elif [ -f "go.mod" ]; then
    echo "Running Go tests..."
    go test -v 2>&1 | tail -50
else
    echo "No test framework detected"
fi
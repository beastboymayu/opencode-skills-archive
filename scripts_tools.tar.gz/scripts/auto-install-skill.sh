#!/bin/bash
# Auto-Install Workflow for OpenCode Agents
# Enables autonomous skill installation when needed
#
# This script is designed to be called by agents when they encounter
# a skill that isn't pre-loaded. It handles:
# 1. Skill discovery in skills.sh
# 2. Automatic installation with verification
# 3. Fallback to npx skills add
#
# Usage:
#   ./auto-install-skill.sh <skill-name>
#   ./auto-install-skill.sh --check <skill-name>  # Check if available
#   ./auto-install-skill.sh --install <owner/repo/skill>  # Direct install

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="/.agents/skills"
INSTALL_SCRIPT="$SCRIPT_DIR/install-skill.sh"

usage() {
    cat <<EOF
Auto-Install Skill Workflow

Usage:
  $0 <skill-name>           Auto-install missing skill
  $0 --check <skill-name>  Check if skill can be installed
  $0 --install <full-ref>   Install from owner/repo/skill
  $0 --search <query>      Search before installing

Examples:
  $0 seo-audit
  $0 --check playwright-pro
  $0 --search "react testing"
EOF
    exit 1
}

# Check if skill exists locally
skill_exists_locally() {
    local skill_name="$1"
    [ -d "$SKILLS_DIR/$skill_name" ] && [ -f "$SKILLS_DIR/$skill_name/SKILL.md" ]
}

# Check if skill is available in pre-loaded library
skill_in_library() {
    local skill_name="$1"
    [ -d "$SKILLS_DIR/$skill_name" ]
}

# Auto-install skill using multiple strategies
auto_install() {
    local skill_name="$1"
    
    echo -e "${CYAN}Auto-installing: $skill_name${NC}"
    
    # Check if already exists
    if skill_exists_locally "$skill_name"; then
        echo -e "${GREEN}✓${NC} Skill already available: $skill_name"
        return 0
    fi
    
    # Strategy 1: Try gitHub-based installation via known skill pack repos
    local sources=(
        "vercel-labs/skills"
        "vercel-labs/agent-skills"
        "obra/superpowers"
        "coreyhaines31/marketingskills"
        "inferen-sh/skills"
        "currents-dev/playwright"
    )
    
    for source in "${sources[@]}"; do
        echo -e "${YELLOW}Trying: $source${NC}"
        if "$INSTALL_SCRIPT" "$source/$skill_name" 2>/dev/null; then
            echo -e "${GREEN}✓${NC} Installed from $source"
            return 0
        fi
    done
    
    # Strategy 2: Try skills.sh search and install
    echo -e "${YELLOW}Searching skills.sh for: $skill_name${NC}"
    local search_results
    search_results=$(curl -s --max-time 10 \
        "https://api.github.com/search/repositories?q=$skill_name+skills+in:name&per_page=5" \
        2>/dev/null | jq -r '.items[]?.full_name' 2>/dev/null) || true
    
    if [ -n "$search_results" ]; then
        for repo in $search_results; do
            echo -e "${YELLOW}Found: $repo${NC}"
            # Try to install - this is a best-effort
            if "$INSTALL_SCRIPT" "$repo/$skill_name" 2>/dev/null; then
                echo -e "${GREEN}✓${NC} Installed from search"
                return 0
            fi
        done
    fi
    
    # Strategy 3: Use npx skills add as fallback
    echo -e "${YELLOW}Attempting skills.sh CLI: npx -y skills add${NC}"
    if command -v npx &>/dev/null; then
        if npx -y skills add "https://github.com/vercel-labs/skills" \
            --skill "$skill_name" --yes 2>/dev/null; then
            echo -e "${GREEN}✓${NC} Installed via skills add"
            return 0
        fi
    fi
    
    echo -e "${RED}✗${NC} Could not auto-install: $skill_name"
    return 1
}

# Check if skill can be installed
check_skill() {
    local skill_name="$1"
    
    if skill_exists_locally "$skill_name"; then
        echo -e "${GREEN}Available locally: $skill_name${NC}"
        return 0
    fi
    
    echo -e "${YELLOW}Not found locally. Checking remote sources...${NC}"
    
    # Check known sources
    local sources=(
        "vercel-labs/skills"
        "vercel-labs/agent-skills" 
    )
    
    for source in "${sources[@]}"; do
        # Quick check without full clone
        if curl -s --max-time 5 "https://api.github.com/repos/$source/contents" 2>/dev/null | \
           jq -r --arg name "$skill_name" '.[] | select(.name == $name)' 2>/dev/null | grep -q .; then
            echo -e "${YELLOW}Available in: $source${NC}"
            echo "Install with: $0 --install $source/$skill_name"
            return 0
        fi
    done
    
    echo -e "${RED}Not found in remote sources${NC}"
    return 1
}

# Direct install from owner/repo
direct_install() {
    local full_ref="$1"
    
    if [[ ! "$full_ref" =~ ^[^/]+/[^/]+/[^/]+$ ]]; then
        echo -e "${RED}Invalid format. Use: owner/repo/skill-name${NC}"
        return 1
    fi
    
    echo -e "${CYAN}Installing: $full_ref${NC}"
    "$INSTALL_SCRIPT" "$full_ref"
}

# Search before install
search_and_offer() {
    local query="$1"
    
    echo -e "${CYAN}Searching skills.sh for: $query${NC}"
    echo "======================================"
    echo ""
    
    local results
    results=$(curl -s --max-time 10 \
        "https://api.github.com/search/repositories?q=$query+skills+in:name,description&per_page=10" \
        2>/dev/null | jq -r '.items[]? | "\(.full_name)|\(.description)"' 2>/dev/null) || true
    
    if [ -z "$results" ]; then
        echo "No results found"
        return 1
    fi
    
    echo "$results" | while IFS='|' read -r name desc; do
        [ -n "$name" ] && echo -e "${GREEN}$name${NC}\n  $desc\n"
    done
    
    echo "To install a skill, run with --install flag"
}

# Main
ACTION="${1:-}"
shift || true

case "$ACTION" in
    --check|-c)
        check_skill "${1:-}" || usage
        ;;
    --install|-i)
        direct_install "${1:-}" || usage
        ;;
    --search|-s)
        search_and_offer "${1:-}" || usage
        ;;
    "")
        # Auto-install mode - takes skill name as argument
        if [ $# -eq 0 ]; then
            usage
        fi
        auto_install "$1"
        ;;
    *)
        if [[ "$ACTION" == -* ]]; then
            usage
        else
            # Treat as skill name for auto-install
            auto_install "$ACTION"
        fi
        ;;
esac
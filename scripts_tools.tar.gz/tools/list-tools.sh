#!/bin/bash
# Available Tools and Scripts
# Lists all custom tools and scripts available

echo "╔═══════════════════════════════════════════════════╗"
echo "║        CUSTOM TOOLS & SCRIPTS REFERENCE          ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "📜 SCRIPTS (in $SCRIPT_DIR):"
echo "─────────────────────────────────────────────────────"
for script in "$SCRIPT_DIR"/*.sh; do
    if [ -f "$script" ]; then
        name=$(basename "$script" .sh)
        echo "  • $name"
    fi
done

echo ""
echo "🐍 PYTHON TOOLS:"
echo "─────────────────────────────────────────────────────"
for tool in "$SCRIPT_DIR"/*.py; do
    if [ -f "$tool" ]; then
        name=$(basename "$tool" .py)
        echo "  • $name"
    fi
done

echo ""
echo "📦 SKILLS (in /.agents/skills/):"
echo "─────────────────────────────────────────────────────"
skill_count=$(ls /.agents/skills/ 2>/dev/null | wc -l)
echo "  Total skills available: $skill_count"
echo "  Run: ls /.agents/skills/ to see all"

echo ""
echo "🤖 CUSTOM AGENTS (in ~/.config/opencode/agents/):"
echo "─────────────────────────────────────────────────────"
for agent in /root/.config/opencode/agents/*.md; do
    if [ -f "$agent" ]; then
        name=$(basename "$agent" .md)
        echo "  • @$name"
    fi
done

echo ""
echo "💡 USAGE:"
echo "─────────────────────────────────────────────────────"
echo "  Scripts: bash ~/.config/opencode/scripts/<name>.sh"
echo "  Agents:  @<agent-name> in your prompt"
echo "  Skills:  Use @skill-name or let AI auto-discover"
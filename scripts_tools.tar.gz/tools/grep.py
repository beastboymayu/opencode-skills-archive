#!/usr/bin/env python3
"""Quick file search with patterns and filters"""

import os
import sys
import re
from pathlib import Path

def search_files(directory, pattern, extensions=None, exclude_dirs=None):
    exclude_dirs = exclude_dirs or ['node_modules', '.git', '__pycache__', 'dist', 'build']
    results = []
    
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if extensions and not any(file.endswith(ext) for ext in extensions):
                continue
                
            filepath = Path(root) / file
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if re.search(pattern, content, re.IGNORECASE):
                        results.append(str(filepath))
            except Exception:
                pass
    
    return results

if __name__ == '__main__':
    directory = sys.argv[1] if len(sys.argv) > 1 else '.'
    pattern = sys.argv[2] if len(sys.argv) > 2 else 'TODO'
    extensions = sys.argv[3].split(',') if len(sys.argv) > 3 else None
    
    results = search_files(directory, pattern, extensions)
    
    print(f"Found {len(results)} files matching '{pattern}':")
    for f in results[:50]:
        print(f"  - {f}")
    if len(results) > 50:
        print(f"  ... and {len(results) - 50} more")